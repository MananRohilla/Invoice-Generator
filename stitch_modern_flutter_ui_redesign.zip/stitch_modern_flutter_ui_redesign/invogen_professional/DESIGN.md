# Design System Strategy: The Sovereign Ledger

## 1. Overview & Creative North Star: "The Sovereign Ledger"
For the Indian small business owner, an invoice isn't just a piece of paper; it’s a testament to their hard work and a claim to their value. Our Creative North Star, **"The Sovereign Ledger,"** moves away from the cluttered, "spreadsheet-heavy" look of traditional accounting software. 

Instead, we lean into a **High-End Editorial** aesthetic. We use intentional asymmetry, expansive negative space, and tonal depth to make the user feel like a CEO, not just a bookkeeper. We break the "template" look by treating the dashboard as a sophisticated workspace where data "breathes" rather than suffocates.

---

## 2. Colors & Surface Architecture
We move beyond flat UI by utilizing a Material-inspired tonal system that prioritizes depth over lines.

### Color Roles
- **Primary (`#7C3AED`):** The "Brand Purple." Use this for high-intent actions and to signify the "InvoGen Authority."
- **Secondary/Accent (`#00BFA5`):** The "Teal Anchor." Used for growth indicators and secondary navigation markers.
- **Surface Hierarchy:** We utilize `surface-container` tiers to create a "nested" physical reality.
    - **Surface (`#F8F9FA`):** The canvas.
    - **Surface-Container-Low (`#F3F4F5`):** For large sectioning.
    - **Surface-Container-Lowest (`#FFFFFF`):** For the "active" interactive cards.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to separate sections. We define boundaries through background color shifts. A card (`surface-container-lowest`) sits on a background (`surface`) to create a natural edge. 

### Signature Textures
- **Stat Card Gradients:** Use linear gradients (`#9333EA` to `#7C3AED`) at a 135° angle to create a sense of forward momentum.
- **The Glass Rule:** For floating modals or "In-Flight" invoice previews, use a `surface-container-lowest` with 80% opacity and a `24px` backdrop-blur to create a "Frosted Glass" effect.

---

## 3. Typography: Editorial Authority
By pairing **Plus Jakarta Sans** (Display) with **Work Sans** (UI), we create a high-contrast hierarchy that feels custom-built.

| Level | Token | Font | Size | Weight | Intent |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Display** | `display-sm` | Plus Jakarta | 2.25rem | Bold | Hero amounts/totals |
| **Headline**| `headline-sm`| Plus Jakarta | 1.5rem | Bold | Section titles (H1 replacement) |
| **Title** | `title-md` | Work Sans | 1.125rem | SemiBold | Card titles (H3 replacement) |
| **Body** | `body-lg` | Work Sans | 1rem | Regular | Content and descriptions |
| **Label** | `label-md` | Work Sans | 0.75rem | Medium | Metadata and micro-copy |

*Director’s Note: Use `display-sm` for the "Total Outstanding" to give the number an authoritative, editorial presence that demands attention.*

---

## 4. Elevation & Depth: Tonal Layering
Traditional shadows are often "dirty." In this system, we use light and tone to achieve lift.

- **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` section. The subtle shift from `#F3F4F5` to `#FFFFFF` creates a "Soft Lift" without a single shadow pixel.
- **Ambient Shadows:** When a card must float (e.g., a hovered invoice), use a highly diffused shadow: `0px 12px 32px rgba(99, 14, 212, 0.06)`. Note the tint—we use a 6% opacity of our `primary` color, not black, to keep the "atmosphere" clean.
- **The Ghost Border:** If a border is required for GST compliance clarity in a table, use `outline-variant` at 15% opacity. Never use 100% solid lines.

---

## 5. Components: The Primitive Set

### Buttons (The "Soul" of Action)
- **Primary:** Background `primary`, `on-primary` text. Radius `12px`.
- **Secondary:** Surface-container-lowest with a `15%` opacity `primary` ghost border.
- **Interaction:** On hover, apply a subtle `primary-container` gradient shift.

### Status Chips (Transparent Resilience)
To maintain an editorial feel, status chips use 20% opacity backgrounds with 100% opacity text.
- **Paid:** Text `#34A853`, BG `#34A85333`.
- **Sent/Draft:** Text `#7C3AED`, BG `#7C3AED33`.
- **Overdue:** Text `#EA4335`, BG `#EA433533`.
- **Shape:** Full pill (`9999px`) for high differentiation from square UI elements.

### The "Sovereign" Input Field
- **Base:** `12px` radius, `surface-container-highest` background.
- **Focus State:** Background shifts to `surface-container-lowest` with a `2px` `primary` "Ghost Border" (20% opacity).
- **Label:** Always use `label-md` floating 8px above the input, never placeholder-only.

### Cards & Lists
- **Rule:** Forbid divider lines.
- **Execution:** Use `24px` vertical padding between list items. Use a subtle `surface-container-low` background on every second item to create "Zebra" grouping without the harshness of lines.

---

## 6. Do’s and Don’ts

### Do
- **Do** use `xl (1.5rem)` corner radius for main dashboard cards to feel approachable and modern.
- **Do** allow the "Brand Purple" to bleed into shadows for a premium, backlit effect.
- **Do** leave "awkward" white space in the margins. It signals luxury and clarity.

### Don't
- **Don't** use a border on a card if it already has a shadow.
- **Don't** use `#000000` for text. Use `on-surface` (`#191C1D`) for an ink-like, professional finish.
- **Don't** cram multiple stat cards together. Give them at least `32px` of breathing room to ensure the GST data is legible and authoritative.